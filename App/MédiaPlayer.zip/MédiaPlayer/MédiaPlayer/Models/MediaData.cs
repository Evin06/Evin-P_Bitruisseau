﻿namespace MédiaPlayer.Models
{
    // Définit les détails des fichiers média stockés ou échangés.
    public class MediaData
    {
        public string FileName { get; set; }
        public string FileArtist { get; set; }  // Artiste du fichier
        public string FileType { get; set; }    // Type de fichier, e.g., "audio/mp3"
        public long FileSize { get; set; }      // Taille du fichier en octets
        public string FileDuration { get; set; } // Durée du fichier, e.g., "03:45" (3 minutes 45 secondes)


        public string GetFormattedDetails()
        {
            return $"{FileName} | {FileArtist} | {FileType} | {FileSize} bytes | Durée: {FileDuration}";
        }
    }

    // Utilisée pour demander un fichier spécifique par son nom.
    public class FileRequest
    {
        public string FileName { get; set; }
    }
}
